import rclpy
from rclpy.node import Node

# from std_msgs.msg import String
from custom_msg_pkg.msg import Num
from rcl_interfaces.msg import ParameterDescriptor, SetParametersResult

class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('minimal_publisher')
        # self.publisher_ = self.create_publisher(String, 'topic', 10)
        self.publisher_ = self.create_publisher(Num, 'topic', 10)
        # timer_period = 0.5  # seconds
        my_timer_period_des = ParameterDescriptor(description='Set the period of the timer')

        self.declare_parameter('my_timer_period', 0.5)
        self.period = self.get_parameter('my_timer_period').value

        self.timer = self.create_timer(self.period, self.timer_callback)
        self.i = 0

        self.add_on_set_parameters_callback(self.on_param_change)

    def on_param_change(self, params):
        # 파라미터가 바뀔 때 호출됨 (ros2 param set …)
        for p in params:
            if p.name == 'my_timer_period':
                try:
                    new_period = float(p.value)
                    if new_period <= 0.0:
                        raise ValueError('period must be > 0')
                except Exception as e:
                    # 이 객체는 “파라미터 변경을 허용할지/거부할지” 를 ROS2에 알려줌
                    return SetParametersResult( 
                        successful=False,
                        reason=f'Invalid period_sec: {e}'
                    )

                # 기존 타이머 취소 → 새 타이머로 교체
                try:
                    self.timer.cancel()
                except Exception:
                    pass
                self.timer = self.create_timer(new_period, self.timer_callback)
                self.period = new_period
                self.get_logger().info(f'Updated timer period to {new_period:.3f}s')

        # 이 객체는 “파라미터 변경을 허용할지/거부할지” 를 ROS2에 알려줌
        return SetParametersResult(successful=True)

    def timer_callback(self):
        # msg = String()
        # msg.data = 'Hello World: %d' % self.i
        msg = Num()
        msg.num = self.i
        self.publisher_.publish(msg)
        # self.get_logger().info('Publishing: "%s"' % msg.data)
        self.get_logger().info('Publishing: "%d"' % msg.num)
        self.i += 1


def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()

    rclpy.spin(minimal_publisher)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()